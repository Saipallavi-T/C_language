//3 numbers in a line
#include<stdio.h>
main()
{
	int i=1,n,count=1,k;
	printf("Enter number of lines\n");
	scanf("%d",&n);
	for(;i<=n;i++)
	{
		for(k=1;k<=3;k++)
		{
			printf("%4d",count);
			count++;
		}
		printf("\n");
	}
}
