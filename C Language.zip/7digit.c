#include<stdio.h>
main()
{
	int n,x,i=1,sum,m;
	m=n;
	printf("Enter a 7 didgit number");
	scanf("%d",&n);
	while(n>=0)
	{
	x=n%10;
	sum=sum+x;
	n=n/10;	
	}
	m=m%1000;
	m=m/100;
	sum=sum-m;
	if(m==sum)
	{
		printf("VALID");
	}
	else
	{
		printf("NOT VALID");
	}
}
