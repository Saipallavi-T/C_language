#include<stdio.h>
main()
{
   int a,b,c;
   scanf("%d %d",&a,&b);
   printf("%d %d",(a+b)-a,(a+b)-b);
}
