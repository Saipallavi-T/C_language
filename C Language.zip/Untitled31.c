#include<stdio.h>
int large(int,int []);
main()
{
	int n,i,a[10],d,pos;
	printf("Enter no.of elemenrs\n");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
    	scanf("%d",&a[i]);
	}
	printf("Enter posion\n");
	scanf("%d",&pos);
	printf("Enter element\n");
	scanf("%d",&d);
	for(i=n-1;i>=pos;i--)
	a[i+1]=a[i];
	a[pos]=d;
    for(i=0;i<=n;i++)
    {
    printf("%d",a[i]);
	}
}
