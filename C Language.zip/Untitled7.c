#include<stdio.h>
main()
{
	int a[10][10],b[10][10],c[10][10],i,j,m,n,o,p;
	printf("Enter order");
	scanf("%d %d",&m,&n);
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
		for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%3d",a[i][j]);
		}
		printf("\n");
    }
    	printf("Enter order");
	scanf("%d %d",&o,&p);
	for(i=0;i<o;i++)
	{
		for(j=0;j<p;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
		for(i=0;i<o;i++)
	{
		for(j=0;j<p;j++)
		{
			printf("%3d",a[i][j]);
		}
		printf("\n");
    }
	for(i=0;i<o,i<m;i++)
	{
		for(j=0;j<p,j<n;j++)
		{
			printf("%3d",a[i][j]+b[i][j]);
		}
		printf("\n");
	}
}
