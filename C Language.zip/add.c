extern int a,b;
void add1(int a,int b)
{
	printf("Result=%d",a+b);
}
