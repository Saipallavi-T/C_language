//ARMSTRONG PROGRAM
#include<stdio.h>
main()
{
	int n,m,x,a;
	printf("Enter a number\n");
	scanf("%d",&n);
	m=n;
	for(a=0;n>0;n=n/10)
	{
	   x=n%10;
	   a=a+(x*x*x);
    }
	if(m==a)
	{
		printf("A armstrong");
	}
	else
	{
		printf("Not a armstrong");
	}
}
