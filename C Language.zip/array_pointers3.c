#include<stdio.h>
main()
{
	int a[10],n,*p,*l,large=0;
	l=&large;
	printf("Enter n\n");
	scanf("%d",&n);
	int i;
	p=&a[0];
	for(i=0;i<n;i++)
	scanf("%d",p+i);
	for(i=0;i<=n;i++)
	{
	*l=*l+*(p+i);
    }
    printf("sum of elements=%d",*l);
}
