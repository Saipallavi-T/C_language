#include<stdio.h>
#include<string.h>
void str();
main()
{
	char a[50];
	gets(a);
	str(a);
}
void str(char a[])
{
	puts(a);
}
