#include<stdio.h>
int i,j;
void displaya(int,int,int[][10]);
void reada(int,int,int[][10]);
void displayb(int,int,int[][10]);
void readb(int,int,int[][10]);
main()
{
	int a[10][10],b[10][10],i,n,m,n1,m1;
	printf("enter order of a\n");
	scanf("%d %d",&m,&n);
	reada(m,n,a);
	displaya(m,n,a);
	printf("enter order b\n");
	scanf("%d %d",&m1,&n1);
	readb(m1,n1,b);
	displayb(m1,n1,b);
}
void displaya(int m,int n,int a[][10])
{
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	printf("%3d",a[i][j]);
	printf("\n");
    } 
}
void reada(int m,int n,int a[][10])
{
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	scanf("%d",&a[i][j]);
    }
}
void displayb(int m1,int n1,int b[][10])
{
	for(i=0;i<m1;i++)
	{
	for(j=0;j<n1;j++)
	printf("%3d",b[i][j]);
	printf("\n");
    } 
}
void readb(int m1,int n1,int b[][10])
{
	for(i=0;i<m1;i++)
	{
	for(j=0;j<n1;j++)
	scanf("%d",&b[i][j]);
    }
}
