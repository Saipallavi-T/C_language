#include<stdio.h>
#include<string.h>
main()
{
	char str[50],re[50],j=0;
	printf("Enter String\n");
	gets(str);
	int i=0;
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]<96)
		{
		re[j]=str[i]+32;
		j++;
	    }
	    else
	    {
	    re[j]=str-32;
		}
	}
	puts(re);c
