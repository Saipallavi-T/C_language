#include<stdio.h>
#include<string.h>
main()
{
	char str[50];
	printf("Enter String\n");
	gets(str);
	int i=0;
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]<96 && str[i]!=32)
		{
		printf("%c",str[i]+32);
	    }
	    else if(str[i]==32)
	    printf(" ");
	    else
	    {
	    printf("%c",str[i]-32);
		}
	}
}
