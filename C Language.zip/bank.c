#include<stdio.h>
int i;
struct bank
{
	char name[50];
	long long int acnt_num;
	char address[50];
	int amt;
	long long int phn_num;
}e[10];
struct bank read(int);
struct bank del(int);
main()
{
	int n,ch,k=0;
	char c;
	do
	{
		printf("1.read\n2.display\n3.Delet\n");
		printf("\n enter yor choice");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("Enter no.of customers");
			scanf("%d",&n);
			printf("Enter customer details\n");
			for(i=0;i<n;i++)
			e[i]=read(n);
			break;
			case 2:display(e,n);
			break;
			case 3:e[i]=del(n);
			k++;
			display(e,n-k);
			break;
			}
			printf("press y to continue");
			scanf(" %c",&c);
		}while(c=='y');
	}
void display(struct bank e[],int(n))
{
	printf("-----------------------------Bank Details-----------------------------\n");
	printf("Name\t\t\tAccount Number\t\tAdress\t\t\tAmount\t\tContact Number\n");
	for(i=0;i<n;i++)
	printf("%s\t\t\t%lld\t\t%s\t\t%d\t\t%lld\n",e[i].name,e[i].acnt_num,e[i].address,e[i].amt,e[i].phn_num);
}
struct bank read(int n)
{
	printf("Name:");
	scanf("%s",e[i].name);
	printf("Account Number:");
	scanf("%lld",&e[i].acnt_num);
	printf("Address:");
	scanf("%s",e[i].address);
	printf("Amount:");
	scanf("%d",&e[i].amt);
	printf("Phone number");
	scanf("%lld",&e[i].phn_num);
	//scanf("%s %lld %s %d %lld",e[i].name,&e[i].acnt_num,e[i].address,&e[i].amt,&e[i].phn_num);
	return e[i];
}
struct bank del(int n)
{
	int pos;
	printf("Enter position you want to delet");
	scanf("%d",&pos);
	for(i=pos-1;i<n;i++)
	e[i]=e[i+1];
}
