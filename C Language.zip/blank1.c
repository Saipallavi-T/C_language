#include<stdio.h>
#include<string.h>
main()
{
	char str[50],i,j;
	printf("Enter String\n");
	gets(str);
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]==32 && str[i+1]==32)
		{
			for(j=i+1;str[j]!='\0';j++)
			{
				str[j]=str[j+1];
			}
		}
	}
	puts(str);
}
