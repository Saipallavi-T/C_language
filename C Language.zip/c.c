#include<stdio.h>
main()
{
	int i,fact,sum=0,n,m,x; 
	printf("Enter your number\n");
	scanf("%d",&n);
	while(n>0)
	{
		x=n%10;
		for(i=1,fact=1;i<=x;i++)
		{
			fact=fact*i;
		}
		sum=sum+fact;
		n=n/10;
	}
	printf("\nresult=%d",sum);
}
