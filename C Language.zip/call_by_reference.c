#include<stdio.h>
void swap(int *,int *);
main()
{
	int x,y;
	printf("Enter any two numbers:");
	scanf("%d %d",&x,&y);
	swap(&x,&y);
	printf("\nAfter swap function x,y are %d %d\n",x,y);
}
void swap(int *a,int *b)
{
	int t;
	t=*a;//
	*a=*b;
	*b=t;
	printf("\na,b values in swap function %d %d",*a,*b);
}
