#include<stdio.h>
#include<string.h>
main()
{
	char str1[50],str2[50],j=1;
	printf("Enter String 1\n");
	gets(str1);
	printf("Enter String 2\n");
	gets(str2);
	int i,l=0,x;
	for(i=0;str2[i]!='\0';i++)
	{
	   l++;	
	}
	for(i=0;str1[i]!='\0';i++)
	{
		str2[l]=str1[i];
		l++;
	}
	puts(str2);
}
