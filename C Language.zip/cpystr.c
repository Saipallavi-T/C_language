#include<stdio.h>
#include<string.h>
main()
{
	char str[50],str1[50];
	printf("Enter String\n");
	gets(str);
	int i,j=0;
	for(i=0;str[i]!='\0';i++)
	{
	   str1[j]=str[i];
	   j++;	
	}
	puts(str1);
	printf("%c",32);
}
he llo we  lcome
