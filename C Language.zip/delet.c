#include<stdio.h>
int pos(int,int,int []);
main()
{
	int n,a[10],i,s,m;
	printf("Enter no.of elements\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("Enter your position\n");
	scanf("%d",&s);
	search(n,s,a);
}
int search(int n, int s,int a[])
{
	int i;
	for(i=s-1;i<n;i++)
	{
	a[i]=a[i+1];
    }
    for(i=0;i<n-1;i++)
	printf("%3d",a[i]);
}
