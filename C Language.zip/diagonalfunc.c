#include<stdio.h>
void diagonal(int,int,int [][10]);
main()
{
	int a[10][10],i,n,m,j;
	printf("enter order\n");
	scanf("%d %d",&m,&n);
	printf("enter elements\n");
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	scanf("%d",&a[i][j]);
    }
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	printf("%3d",a[i][j]);
	printf("\n");
    } 
    printf("Diagonal elements\n");
    diagonal(m,n,a);
}
void diagonal(int m,int n,int a[][10])
{   
    int i,j;
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	{
	if(i==j)
	printf("%3d",a[i][j]);
	else
	printf("  ");
    }
	printf("\n");
    } 
}
