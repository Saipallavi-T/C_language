extern int a,b;
void div1(int a,int b)
{
	printf("Result=%f",(float)a/(float)b);
}
