#include<stdio.h>
int duplicate(int,int []);
main()
{
	int n,a[10],i;
	printf("Enter no.of elements\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	duplicate(n,a);
}
int duplicate(int n,int a[])
{
	int z,y,flag=1;
	for(z=0;z<n;z++)
	{
		for(y=1;y<n-z;y++)
		{
			if(a[z]==a[z+y])
			flag++;
		}
	}
	printf("No.of duplicate elements are %d",flag);
}
