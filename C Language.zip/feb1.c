#include<stdio.h>
#include<math.h>
main()
{
	int n,sum=0,i;
	printf("Enter a value\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	 printf("%3d",i);
    } 
}

