#include<stdio.h>
main()
{
	int i,j,a[10][10],m,n,k=0,sum=0;
    printf("Enter order");
    scanf("%d %d",&m,&n);
	printf("Enter elements\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
		scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%3d",a[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for(i=0;i=i;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("%3d",a[i][j]);
			sum=sum+a[i][j];
	    }
	    prinf("sum of row%d=%d\n",i+1,sum);
    }
}   
