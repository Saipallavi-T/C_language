#include<stdio.h>
main()
{
	int i,j,a[10][10],m,n,k=0,sum;
    printf("Enter order");
    scanf("%d %d",&m,&n);
	printf("Enter elements\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
		scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
		printf("%3d",a[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for(i=0;i<m;i++)
	{ 
		for(j=0,sum=0;j<n;j++)
		{
		 sum=sum+a[i][j];
	    }
	    printf("sum of row%d=%d\n",i+1,sum);
    }
    printf("\n");
    	for(j=0;j<n;j++)
	{ 
		for(i=0,sum=0;i<m;i++)
		{
		 sum=sum+a[i][j];
	    }
	    printf("sum of coloum%d=%d\n",j+1,sum);
    }
}   
