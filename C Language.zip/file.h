extern x,y;
void sum()
{
	printf("Sum=%d",x+y);
}
void avg()
{
	printf("\nAvg=%d",(x+y)/2);
}
