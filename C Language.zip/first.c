#include<stdio.h>
main()
{
	printf("pramoditha manchikatla");
}
