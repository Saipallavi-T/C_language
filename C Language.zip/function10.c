#include<stdio.h>
void line(int);
main()
{
	int n;
	printf("Enter n value\n");
	scanf("%d",&n);
	printf("0 1");
	line(n);
}
void line(int n)
{
	int sum,f1=0,f2=1,i=1;
	while(i<=(n-2))
	{
	sum=f1+f2;
	printf("%2d",sum);
	i++;
	f1=f2;
	f2=sum;
    }
}
