#include<stdio.h>
int cube(int);
int sum(int);
main()
{
	int n,z1,z2;
	printf("Enter a 7 digit number\n");
	scanf("%d",&n);
	z1=sum(n);
	z2=cube(n);
	if(z1==z2)
	printf("VALID");
	else
	printf("NOT VALID");
}
int sum(int n)
{
	int sum,m,x;
	m=n;
	while(n>0)
	{
		x=n%10;
		sum=sum+x;
		n=n/10;
	}
	m=m%1000;
	m=m/100;
	sum=sum-m;
	return sum;
}
int cube(int n)
{
	int m;
	m=n;
	m=m%1000;
	m=m/100;
	m=m*m*m;
    return m;
}
