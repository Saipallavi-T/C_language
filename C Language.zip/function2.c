#include<stdio.h>
void num(int);
main()
{
	int n,z;
	printf("Enter n value");
	scanf("%d",&n);
	num(n);
}
void num(int n)
{
	int i;
	for(i=1;i<=n;i++)
	printf("%d",i);
}
