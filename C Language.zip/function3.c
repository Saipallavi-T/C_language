#include<stdio.h>
int sum(int);
float avg(int);
main()
{
	int n;
	printf("Enter n value\n");
	scanf("%d",&n);
	printf("Sum=%d\nAverage=%f",sum(n),avg(n));
}
int sum(int n)
{
	int i,sum1;
	for(i=1,sum1=0;i<=n;i++)
    {
      sum1=sum1+i;
	}
	return sum1;
}
float avg(int n)
{
	int i,sum1;
	float avg1;
	for(i=1,sum1=0;i<=n;i++)
    {
      sum1=sum1+i;
	}
	avg1=(float)(sum1)/(float)(n);
	return avg1;
}
