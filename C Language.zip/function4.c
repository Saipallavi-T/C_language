#include<stdio.h>
int isum(int);
main()
{
	int n;
	printf("enter the number\n");
	scanf("%d",&n);
	printf("result=%d",isum(n));
}
isum(int n)
{
	int i,sum=0,x;
	while(n>0)
	{
		x=n%10;
		sum=sum+x;
		n=n/10;
	}
	return sum;
}
