#include<stdio.h>
int armg(int);
main()
{
	int n,z;
	printf("Enter number\n");
	scanf("%d",&n);
	z=armg(n);
	if(n==z)
	printf("Armstrong");
	else
	printf("not a armstrong");
}
int armg(int n)
{
	int x,i,a=0;
	while(n>0)
	{
		x=n%10;
		a=a+(x*x*x);
		n=n/10;
	}
	return a;
}
