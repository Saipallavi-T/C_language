#include<stdio.h>
void display(int,int[]);
main()
{
	int a[10],i,n;
	printf("enter number\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	display(n,a);
}
void display(int n,int a[])
{
	int i;
	for(i=0;i<n;i++)
	printf("%3d",a[i]);
}
