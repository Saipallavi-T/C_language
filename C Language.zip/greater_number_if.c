#include<stdio.h>
main()
{
	int a,b;
	printf("Enter Two Numbers\n");
	scanf("%d %d",&a,&b);
	if(a>b)
	{
		printf("a is grater");
	}
	if(a<b)
	{
		printf("b is grater");
	}
}
