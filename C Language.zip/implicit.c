#include<stdio.h>
main()
{
	short int a,b;
	printf("enter two numbers");
	scanf("%d",&a);
	printf("%d",a);
	printf("%d",b);
	int c;
	printf("h");
	scanf("&d",&c);
}
