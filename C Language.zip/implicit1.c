#include<stdio.h>
main()
{
	short int a;
	int b;
	printf("enter two numbers");
	scanf("%d",&a);
	b=a;
	printf("%d\n",a);
	printf("%d",b);
}
