#include<stdio.h>
main()
{
	int x=10;
	while(x<=10 && x>=1)
	{
		printf("%d\n",x);
		x--;
    }
}
