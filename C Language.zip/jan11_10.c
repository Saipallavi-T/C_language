#include<stdio.h>
main()
{
	int x,y;
	printf("Enter the x and y coordinates\n");
	scanf("%d %d",&x,&y);
	if(x>0&&y>0)
	{
		printf("Quadrant 1");
	}
	else if(x<0&&y>0)
	{
		printf("Quadrant 2");
	}
	else if(x<0&&y<0)
	{
		printf("Quadrant 3");
	}
	else if(x>0&&y<0)
	{
		printf("Quadrant 4");
	}
	else if(x==0&&(y>0||y<0))
	{
		printf("On Y-Axis");
	}
	else if((x<0||x>0)&&y==0)
	{
		printf("On X-Axis");
	}
	else
	{
		printf("Origin");
	}
	
}
