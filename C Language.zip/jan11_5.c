#include<stdio.h>
main()
{
	char c;
	printf("Enter the alphabet");
	scanf("%c",&c);
	if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
	{
		printf("VOWEL");
	}
	else if(c=='A'||c=='E'||c=='I'||c=='O'||c=='U')
	{
		printf("VOWEL");
	}
	else
	{
		printf("CONCONENT");
	}
}
