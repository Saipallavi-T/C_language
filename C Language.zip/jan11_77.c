#include<stdio.h>
main()
{
	int x;
	printf("Enter a Number");
	scanf("%d",&x);
	if(x%2==0)
	{
	 if(x>0)
	 {
	    printf("postive Even Number");
	 }
	 else
	 {
	 	printf("Negative Even Number");
	 }
	}
     else if(x%2==!0)
    {
	 if(x>0)
	 {
	 	printf("postive Odd Number");
	 }
	 else
	 {
	 	printf("Negative Odd Number");
	 }
    }
    else
    {
    	printf("0");
	}
}
