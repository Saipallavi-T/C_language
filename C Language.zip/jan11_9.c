#include<stdio.h>
main()
{
	int a;
	printf("enter a character or digit\n");
	scanf("%c",&a);
	if(a>=65&&a<=90)
	{
		printf("Upper case alphabet");
	}
	else if(a>=97&&a<=122)
	{
		printf("Lower case alphaber");
	}
	else if(a>=48&&a<=57)
	{
		printf("Digits");
	}
    else
    {
    	printf("Special Character");
	}
}	
