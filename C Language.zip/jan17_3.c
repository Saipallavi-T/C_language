#include<stdio.h>
main()
{
	int c;
    printf (" Enter a alphabet");  
    scanf (" %c", &c);  
    int ascii = c+32;  
    printf (" %c character in Lower case is: %c", c,ascii);  
      
}
