#include<stdio.h>
main()
{
	int c;
    printf (" Enter a alphabet\n");  
    scanf (" %c", &c); 
    if(c>=97 && c<=122)  
    {
    	int ascii=c-32;
    	printf("The given character %c in Upper case is %c",c,ascii);
	}
	else
    {
       int ascii1=c+32;
    	printf("The given character %c in Lower case is %c",c,ascii1);
	}
}
