#include<stdio.h>
main()
{
	int x;
	printf("Enter the number");
	scanf("%d",&x);
	if(x>0)
	{
		printf("1");
	}
	if(x==0)
	{
		printf("0");
	}
	if(x<0)
	{
		printf("-1");
	}
}
