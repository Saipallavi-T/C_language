#include<stdio.h>
main()
{
	int x=1,n;
	printf("Enter a number\n");
	scanf("%d",&n);
do
{
	printf("%d\n",x);
	x++;
}while(x<=n);
}

