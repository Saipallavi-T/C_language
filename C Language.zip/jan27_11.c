#include<stdio.h>
main()
{
	int x=1,n;
	char t;
	do
	{
	printf("Enter a number");
	scanf("%d",&n);
	while(x<=n)
	{
		printf("%d\n",x);
		x++;
    }
    printf("\nPress y to continue");
    scanf(" %c",&t);
}while(t=='y');
}

