#include<stdio.h>
main()
{
	int x=1,n;
	char t;
	printf("Enter a number");
	scanf("%d",&n);
	while(x<=n)
	{
		printf("%d\n",x);
		x++;
    }
}

