#include<stdio.h>
main()
{
	int sum,i,n;
	float avg;
	sum=0,i;
	printf("Enter number\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		sum=sum+i;
	}
	avg=(float)(sum)/n;
	printf("The sum of the numbers is %d and avg is %f",sum,avg);
}
