#include<stdio.h>
main()
{
    int n,sum;
    printf("enter a number\n");
    scanf("%d",&n);
   for(sum=0;n>0;n=n/10)
    {
        sum=sum+n%10;
    }
printf("sum of individual digits of a number is %d",sum); 
}
