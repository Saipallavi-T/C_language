#include<stdio.h>
#include<stdlib.h>
main()
{
	char c;
	FILE *f1,*f2;
	printf("enter file data\n");
	f1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/va.txt","a");
	while((c=getchar())!=EOF)
	putc(c,f1);
	fclose(f1);
	f1=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/va.txt","r");
	f2=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/va2.txt","w");
	while((c=getc(f1))!=EOF)
	putc(c,f2);
	fclose(f1);
	fclose(f2);
	f2=fopen("C:/Users/pramo/OneDrive/Desktop/IP/k/va2.txt","r");
	printf("Data in file 2");
	while((c=getc(f2))!=EOF)
	putchar(c);
	fclose(f1);
	fclose(f2);
}
