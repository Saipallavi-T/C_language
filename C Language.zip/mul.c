extern int a,b;
void mul1(int a,int b)
{
	printf("Result=%d",a*b);
}
