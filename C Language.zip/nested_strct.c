struct date
{
	int day;
	int month;
	int year;
};
struct bank
{
	long long int ac_no;
	char name[50];
	struct date b;
};
main()
{
	struct bank d;
	printf("Enter Details:\n");
	scanf("%lld%s%d%d%d",&d.ac_no,d.name,&d.b.day,&d.b.month,&d.b.year);
	printf("----------------------Bank details----------------------\n");
	printf("Acccount Number\t\tName\t\tDate\n");
	scanf("%lld\t\t%s\t\t%d/%d/%d",&d.ac_no,d.name,&d.b.day,&d.b.month,&d.b.year);
}
