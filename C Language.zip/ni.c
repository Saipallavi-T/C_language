#include<stdio.h>
main()
{
  int x,y,z,a;
  printf("1.tiffin\n2.snacks\n3.meals\n\n");
  printf("1.idly\n2.dosa\n3.wada\n\n");
  printf("1.pizza\n2.burger\n\n");
  printf("1.veg\n2.non veg\n\n");
  printf("type of item: ");
  scanf("%d",&x);
   printf("type of food: ");
  scanf("%d",&y);
   printf("no of plates: ");
  scanf("%d",&z);
  switch(x)
  {
  	case 1:switch(y)
	  {
  		case 1:a=z*10;
  		printf("the amount is %d",a);
		break;
	    case 2:a=z*5;
  		printf("the amount is %d",a);
  		break;
    	case 3:a=z*20;
  		printf("the amount is %d",a);
		break;
	  }
	  break;
	case 2:switch(y)
	  {
  		case 1:a=z*100;
  		printf("the amount is %d",a);
		break;
	    case 2:a=z*250;
  		printf("the amount is %d",a);
  		break;
    }
    break;
   case 3:switch(y)
   {
   	  case 1:a=z*50;
      printf("the amount is %d",a);
	  break;
	  case 2:a=z*100;
  	  printf("the  total amount is: %d",a);
  	  break;
    }
    break;
}	
}
