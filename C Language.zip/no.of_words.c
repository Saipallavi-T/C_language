#include<stdio.h>
#include<string.h>
main()
{
	char str[50];
	printf("Enter the String\n");
	gets(str);
	int i=0,count=0;
	for(i=0;str[i]!='0';i++)
	{
		if(str[i]==32)
		count++;
	}
	printf("Words=%d",count+1);
}
