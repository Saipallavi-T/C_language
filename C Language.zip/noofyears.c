1#include<stdio.h>
main()
{
	int a;
	printf("enter no.of days\n");
	scanf("%d",&a);
	int years=a/365;
	printf("no.of years=%d\n",years);
	a=a-years*365;
	int weeks=a/7;
	printf("no.of weeks=%d\n",weeks);
	int days=a%7;
	printf("no.of days =%d\n",days);
}
