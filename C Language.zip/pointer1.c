#include<stdio.h>
main()
{
	int a,b,c,*p1,*p2,*p3;
	printf("Enter two numbers\n");
	p1=&a;
	p2=&b;
	p3=&c;
	scanf("%d %d",p1,p2);
	*p3=*p1+*p2;
	printf("Addition=%d",*p3);
	getch();
}
