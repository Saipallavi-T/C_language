#include<stdio.h>
main()
{
	int a,b,c,*p1,*p2,*p3;
	p1=&a;
	p2=&b;
	p3=&c;
	printf("Enter two numbers\n");
	scanf("%d %d %d",p1,p2,p3);
	if(*p1>*p2 && *p1>*p2)
	printf("%d is greatest",*p1);
	else if(*p2>*p3 && *p2>*p1)
	printf("%d is greatest",*p2);
	else
	printf("%d is greatest",*p3);
}
