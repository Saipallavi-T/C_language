#include<stdio.h>
main()
{
	int a,b,c,*p1,*p2,*p3;
	printf("Enter two numbers\n");
	p1=&a;
	scanf("%d",p1);
	if(*p1%2==0)
	printf("%d is Even",*p1);
	else
	printf("%d is Odd",*p1);
}
