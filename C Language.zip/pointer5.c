#include<stdio.h>
main()
{
	int a,b,c,d,total,*p1,*p2,*p3,*p4,*t;
	float per,*pp;
	p1=&a;
	p2=&b;
	p3=&c;
	p4=&d;
	t=&total;
	pp=&per;
	printf("Enter Marks\n");
	scanf("%d %d %d %d",p1,p2,p3,p4);
	*t=*p1+*p2+*p3+*p4;
	*pp=(float)(*t)/4;
	if(*pp>=90)
	printf("A");
	else if(*pp>=80)
	printf("B");
	else if(*pp>=70)
	printf("C");
	else if(*pp>=60)
	printf("D");
	else if(*pp>=50)
	printf("E");
	else
	printf("F");
}
