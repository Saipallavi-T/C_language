#include<stdio.h>
main()
{
	int a[10],*p[10],n,*n1,sum=0,*sum1,large=0;
	n1=&n;
	sum1=&sum;
	printf("Enter n value");
	scanf("%d",n1);
	int i;
	for(i=0;i<*n1;i++)
	{
		p[i]=&a[i];
	}
	printf("Enter values");
	for(i=0;i<*n1;i++)
	{
	scanf("%d",p[i]);
	}
	for(i=0;i<*n1;i++)
	{
	 if(*p[i]>large)
	 large=*p[i];
	}
	printf("Largest Element=%d",large);
}
