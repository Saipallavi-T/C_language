#include<stdio.h>
main()
{
	char s[10],*p;
	int len=0,*len1;
	p=&s[0];
	len1=&len;
	printf("Enter String\n");
	gets(s);
	while(*p!='\0')
	{
		*p++;
		*len1=*len1+1;
    }
	printf("Length=%d",*len1);
}
