#include<stdio.h>
main()
{
	char s[10],*p,*q,r[10];
	int len=0,*len1,i=0,j=0,*j1;
	p=s;
	q=r;
	j1=&j;
	len1=&len;
	printf("Enter String\n");
	gets(s);
	for(;*p!='\0';p++)
	{
		*len1=*len1+1;
    }
   for(i=0;i<=*len1-1;i++)
   {
   	p--;
   }
   for(i=0;i<=*len1-1;i++)
   {
   	*q=*p;
   	p++;
   	q++;
   }
   *(q)='\0';
   puts(r);
}
