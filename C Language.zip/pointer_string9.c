#include<stdio.h>
main()
{
	char s[10],*p,*len1,len;
	int i;
	p=s;
	len1=&len;
	printf("Enter String\n");
	gets(s);
	for(;*p!='\0';p++)
	{
		*len1=*len1+1;
    }
    for(i=0;i<=*len1-1;i++)
   	p--;
	if(*p<96)
	{
		for(i=0;i<=*len1-1;i++)
		{
		printf("%c",*(p)+32);
	    p++;
		}
	}
	else
	{
		for(i=0;i<=*len1-1;i++)
		{
		printf("%c",*(p)-32);
		p++;
	    }
	}
}
