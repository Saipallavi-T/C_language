#include<stdio.h>
int power(int,int,int);
main()
{
	int a,b,z,x=0;
	printf("Enter number\n");
	scanf("%d",&a);
	printf("Enter power\n");
	scanf("%d",&b);
	z=power(a,x,b);
	printf("Power is %d",z);
}
int power(int a,int x,int b)
{
	if(x==b)
	return 1;
	else
    return (a*power(a,x+1,b));
}
