#include<stdio.h>
#include<math.h>
main()
{
	float a,b,c,d;
	printf("enter three numbers");
	scanf("%f %f %f",&a,&b,&c);
	d=5-3+4/
}
