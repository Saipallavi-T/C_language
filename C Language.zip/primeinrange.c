#include<stdio.h>
void prange(int,int);
main()
{
	int a,b,i,count,z;
	printf("Enter Range\n");
	scanf("%d %d",&a,&b);
	prange(a,b);
}
void prange(int a,int b)	
{
	int i,count,z;
		for(z=a;z<=b;z++)
	{   
	    if(z==1)
	    printf("1");
		count=0;
		for(i=1;i<=z;i++)
		{
			if(z%i==0)
			count++;
		}
		if(count==2)
		printf("%3d",z);
	}
}
