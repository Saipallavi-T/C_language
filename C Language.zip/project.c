#include<stdio.h>
int i,eid,ei=0,n;
char ech;
struct elctronic_items
{
	int id;
	char item_name[50];
	char cpny_name[50];
	int price;
	int rating;
};
struct elctronic_cart
{
	int id;
	char item_name[50];
	int price;
}ec[10];
struct books
{
	int id;
	char item_name[50];
	char author_name[50];
	int price;
	int rating;
};
struct shoes{
	int id;
	char brand[50];
	int price;
	int rating;
};
void ele_item();
void book();
void shoe();
main()
{
	int n,ch,ic,p;
	char c;
	do{
		printf("1.Display all kind of items available\n2.Display the total no.of items added\n3.Bill the items selected\n");
		printf("\nenter yor choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("1.Electronic Items\n");
			       printf("2.Books\n");
			       printf("3.Shoes\n");
			       printf("choose the kind of item you want to buy:");
			       scanf("%d",&ic);
			       switch(ic)
			       {
			       	case 1:printf("Id\tItem\t\tCompany\t\tPrice\t\tRating\n");
			       	       ele_item();
						   break;
                    case 2:printf("Id\tName\t\t\t\tAuthor Name\t\t\tPrice\t\t\tRating\n");
			       	       book();
			       	       break;
			       	case 3:printf("Id\tBrand\t\tPrice\tRating\n");
			       	       shoe();
				   }
				   break;
			case 2:display(ec,ei);
			        break;
	}
	printf("press y to continue:");
	scanf(" %c",&c);
}while(c=='y');
}
void ele_item()
{
	struct elctronic_items e1={1,"Laptop","HP",65990,8};
	struct elctronic_items e2={2,"Mobile","Samsung",20300,9};
	struct elctronic_items e3={3,"Oven","Philips",7999,10};
	struct elctronic_items e4={4,"Camera","Canon",75000,7};
	struct elctronic_items e5={5,"Airpods","Apple",29999,9};
	printf("%d\t%s\t\t%s\t\t%d\t\t%d\n",e1.id,e1.item_name,e1.cpny_name,e1.price,e1.rating);
	printf("%d\t%s\t\t%s\t\t%d\t\t%d\n",e2.id,e2.item_name,e2.cpny_name,e2.price,e2.rating);
	printf("%d\t%s\t\t%s\t\t%d\t\t%d\n",e3.id,e3.item_name,e3.cpny_name,e3.price,e3.rating);
	printf("%d\t%s\t\t%s\t\t%d\t\t%d\n",e4.id,e4.item_name,e4.cpny_name,e4.price,e4.rating);
	printf("%d\t%s\t\t%s\t\t%d\t\t%d\n",e5.id,e5.item_name,e5.cpny_name,e4.price,e5.rating);
	do{
	printf("Enter the Id of the product you want to add to cart:");
	scanf("%d",&eid);
	switch(eid)
	{
		case 1:ec[ei].id=e1.id;
		       strcpy(ec[ei].item_name,e1.item_name);
		       ec[ei].price=e1.price;
		       ei++;
	           break;
	    case 2:ec[ei].id=e1.id;
		       strcpy(ec[ei].item_name,e1.item_name);
		       ec[ei].price=e1.price;
		       ei++;
	           break;
	    case 3:ec[ei].id=e1.id;
		       strcpy(ec[ei].item_name,e1.item_name);
		       ec[ei].price=e1.price;
		       ei++;
	           break;
	    case 4:ec[ei].id=e1.id;
		       strcpy(ec[ei].item_name,e1.item_name);
		       ec[ei].price=e1.price;
		       ei++;
	           break;
	    case 5:ec[ei].id=e1.id;
		       strcpy(ec[ei].item_name,e1.item_name);
		       ec[ei].price=e1.price;
		       ei++;
	           break;	
	 }
	 printf("Press e if you want add anymore products from electronics:");
	 scanf(" %c",&ech);
}while(ech=='e');
}
void book()
{
	struct books b1={1,"Alchemist","Paulo Coelho",227,7};
    struct books b2={2,"Wings Of Fire","Abdul Kalam",400,9};
    struct books b3={3,"Ikigai   ","Hector Garciar",356,8};
    struct books b4={4,"You Can   ","George Adams",112,7};
    struct books b5={5,"Gone Girl","Gillian Flynn",189,9};
	printf("%d\t%s\t\t\t%s\t\t\t%d\t\t\t%d\n",b1.id,b1.item_name,b1.author_name,b1.price,b1.rating);
	printf("%d\t%s\t\t\t%s\t\t\t%d\t\t\t%d\n",b2.id,b2.item_name,b2.author_name,b2.price,b2.rating);
	printf("%d\t%s\t\t\t%s\t\t\t%d\t\t\t%d\n",b3.id,b3.item_name,b3.author_name,b3.price,b3.rating);
	printf("%d\t%s\t\t\t%s\t\t\t%d\t\t\t%d\n",b4.id,b4.item_name,b4.author_name,b4.price,b4.rating);
	printf("%d\t%s\t\t\t%s\t\t\t%d\t\t\t%d\n",b5.id,b5.item_name,b5.author_name,b5.price,b5.rating);	
}
void shoe()
{
   struct shoes s1={1,"Nike    ",5698,7};
   struct shoes s2={2,"Adidas  ",5999,8};
   struct shoes s3={3,"Puma    ",2999,9};
   struct shoes s4={4,"Reebok  ",3998,6};
   struct shoes s5={5,"SKECHERS",3985,9};	
   printf("%d\t%s\t%d\t%d\n",s1.id,s1.brand,s1.price,s1.rating);
   printf("%d\t%s\t%d\t%d\n",s2.id,s2.brand,s2.price,s2.rating);
   printf("%d\t%s\t%d\t%d\n",s3.id,s3.brand,s3.price,s3.rating);
   printf("%d\t%s\t%d\t%d\n",s4.id,s4.brand,s4.price,s4.rating);
   printf("%d\t%s\t%d\t%d\n",s5.id,s5.brand,s5.price,s5.rating);
}
display(struct elctronic_cart ec[],int(n))
{
	printf("Name\t\tprice\n");
	for(i=0;i<n;i++)
	printf("%s\t\t%d\n",ec[i].item_name,ec[i].price);
}
