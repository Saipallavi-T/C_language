#include<stdio.h>
main()
{
	int *p1,*p2,i,n,m,j;
	printf("enter n value:");
	scanf("%d",&n);
	printf("Enter m value:");
	scanf("%d",&m);
	int k=n*m;
	p1=(int *)malloc(k*sizeof(int));
	printf("Enter values");
	for(i=0;i<k;i++)
	scanf("%d",p1+i);
	p2=(int *)malloc(k*sizeof(int));
	printf("Enter values");
	for(i=0;i<k;i++)
	scanf("%d",p2+i);
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		printf("%3d",*(p1+i*m+j)+*(p2+i*m+j));
		printf("\n");
	}
}
