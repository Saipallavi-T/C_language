#include<stdio.h>
union book
{
	char name[50];
	int price;
	int pages;
};
main()
{
	union book b;
	printf("Enter Book Name:");
	scanf("%s",b.name);
	printf("Book Name:%s\n",b.name);
	printf("Enter Book Price:");
	scanf("%d",&b.price);
	printf("Book Name:%d\n",b.price);
	printf("Enter Book Pages:");
	scanf("%d",&b.pages);
	printf("Book Name:%d",b.pages);
}
