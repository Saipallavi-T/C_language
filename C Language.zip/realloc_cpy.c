#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p,str[50];
	int n1,n2,i;
	printf("Enter size of string:");
	scanf("%d",&n1);
	p=(char *)malloc(n1*sizeof(char));
	printf("Enter String:");
	for(i=0;i<=n1;i++)
	scanf("%c",p+i);
    for(i=0;i<=n1;i++)
	str[i]=*(p+i);
	puts(str);
	printf("\nEnter new size of 1st string:");
	scanf("%d",&n2);
	p=(char *)realloc(p,n2*sizeof(char));
    printf("Enter String:");
	for(i=0;i<=n2;i++)
	scanf("%c",p+i);
    for(i=0;i<=n2;i++)
	str[i]=*(p+i);
	puts(str);
	free(p);
}
