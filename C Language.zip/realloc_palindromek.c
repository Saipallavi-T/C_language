#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p,str[50];
	int n1,n2,i,j,flag=0;
	printf("Enter size:");
	scanf("%d",&n1);
	p=(char *)malloc(n1*sizeof(char));
	for(i=0;i<=n1;i++)
	scanf("%c",p+i);
	p++;
    for(i=0;i<=n1;i++)
	{
		if(*(p+i)==*(p+n1-i-1))
		flag++;
	}
	if(flag==n1)
	printf("Palindrome");
	else
	printf("Not a Palindrome");
	flag=0;
	printf("\nEnter new size:");
	scanf("%d",&n2);
	p=(char *)realloc(p,n2*sizeof(char));
	for(i=0;i<=n2;i++)
	scanf("%c",p+i);
	p++;
    for(i=0;i<=n2;i++)
	{
		printf("%c\n",*(p+i));
    	printf("%c\n",*(p+n2-i-1));
		if(*(p+i)==*(p+n2-i-1))
		flag++;
	}
	printf("%d",flag);
	if(flag==n2)
	printf("Palindrome");
	else
	printf("Not a Palindrome");
	free(p);
}
