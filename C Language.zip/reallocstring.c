#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p;
	int n1,n2,i,l1=0,l2=0;
	printf("Enter size:");
	scanf("%d",&n1);
	p=(char *)malloc(n1*sizeof(char));
	for(i=0;i<=n1;i++)
	scanf("%c",p+i);
	for(i=0;*(p+i)!='\0';i++)
	l1++;
	printf("Length=%d",l1-1);
	printf("\nEnter new size:");
	scanf("%d",&n2);
	p=(char*)realloc(p,n2*sizeof(char));
	for(i=0;i<=n2;i++)
	scanf("%c",p+i);
	for(i=0;*(p+i)!='\0';i++)
	l2++;
	printf("Length=%d",l2-1);
	free(p);
}
