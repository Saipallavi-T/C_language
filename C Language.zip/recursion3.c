#include<stdio.h>
int display(int);
main()
{
	int x=0,n;
	printf("Enter a number\n");
	scanf("%d",&n);
    display(n);
}
int display(int n)
{
	if(n==0)
	return;
	else
	printf("%2d",n);
	display(n-1);
}
