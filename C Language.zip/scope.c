#include<stdio.h>
main()
{
	int i;
	for(i=1;i<=3;i++)
	{
		register x=0;
		x++;
		printf("\t%d",x);
	}
}
