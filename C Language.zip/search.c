#include<stdio.h>
int search(int,int,int []);
main()
{
	int n,a[10],i,s;
	printf("Enter no.of elements\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("Enter your element\n");
	scanf("%d",&s);
	search(n,s,a);
}
int search(int n, int s,int a[])
{
	int i;
	for(i=0;i<n;i++)
	{
	if(a[i]==s)
	{
	printf("FOUND");
	break;
    }
    }
}
