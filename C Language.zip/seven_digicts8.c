#include<stdio.h>
main()
{
	int n,x,i=1,sum=0,m;
	printf("Enter a 7 didgit number\n");
	scanf("%d",&n);
	m=n;
	for(;n>0;n=n/10)
	{
	sum=sum+n%10;
	}
	m=m%1000;
	m=m/100;
	if((m*m*m)==(sum-m))
	{
	 printf("VALID");
	}
	else
	{
	 printf("NOT VALID");
	}
}
