#include<stdio.h>
main()
{
	int n,x,i=1,sum=0,m;
	m=n;
	printf("Enter a 7 didgit number\n");
	scanf("%d",&n);
	while(n>0)
	{
	x=n%10;
	sum=sum+x;
	n=n/10;	
	}
	printf("%d",sum);
	m=m%1000;
	m=m/100;
	pritf("%d",m);
	if(m==(sum-m))
	{
		printf("VALID");
	}
	else
	{
		printf("NOT VALID");
	}
}
