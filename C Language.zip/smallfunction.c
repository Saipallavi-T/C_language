#include<stdio.h>
int large(int,int[]);
main()
{
	int a[10],i,n,d;
	printf("enter number\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	d=large(n,a);
	printf("small=%d",d);
}
int large(int n,int a[])
{
	int i,n1=99999999;
	for(i=0;i<n;i++)
	{
		if(a[i]<n1)
		n1=a[i];
	}
	return n1;
}
