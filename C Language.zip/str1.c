#include<stdio.h>
main()
{
	int z;
	char str[10];
	gets(str);
	z=strlen(str);
	printf("%d",z);
}
