#include<stdio.h>
main()
{
	int z;
	char str[10];
	gets(str);
	strrev(str);
	puts(str);
}
