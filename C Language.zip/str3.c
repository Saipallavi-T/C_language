#include<string.h>
#include<stdio.h>
main()
{
	int z;
	char str1[10],str2[10];
	gets(str1);
	strcpy(str2,str1);
	puts(str1);
	puts(str2);
}
