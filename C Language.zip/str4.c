#include<string.h>
#include<stdio.h>
main()
{
	int z;
	char str1[10],str2[10];
	gets(str1);
	gets(str2);
	z=strcmp(str2,str1);
	if(z==0)
    printf("Same");
    else
    printf("Not same");
}
