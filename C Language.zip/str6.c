#include<string.h>
#include<stdio.h>
main()
{
	char str1[10],str2[10];
	int n;
	printf("Enter two strings\n");
	gets(str1);
	gets(str2);
	n=strstr(str1,str2);
	if(n==0)
	printf("the sub string is not present");
	else
	printf("the sub string is present in main string");
}

