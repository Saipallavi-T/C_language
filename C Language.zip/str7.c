#include<stdio.h>
main()
{
	char str[10],str1[10];
	gets(str);
	gets(str1);
    strupr(str);
	strlwr(str1);
	puts(str);
	puts(str1);
}
