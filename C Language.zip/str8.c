#include<stdio.h>
main()
{
	int z;
	char str[10];
	gets(str);
    strlwr(str);
	puts(str);
}
