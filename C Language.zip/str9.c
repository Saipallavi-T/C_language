#include<stdio.h>
#include<string.h>
main()
{
	int l=0;
	char str[50];
	printf("Enter string\n");
	gets(str);
	int i;
	for(i=0;str[i]!='\0';i++)
	l++;
	printf("Length=%d",l);
}
