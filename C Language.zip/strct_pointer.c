struct student
{
	char name[10];
	int age;
	int marks;
	char branch[10];
};
main()
{
	struct student *p,s;
	p=&s;
	printf("enter student details\n");
	scanf("%s%d%d%s",p->name,&p->age,&p->marks,p->branch);
	printf("Name\tAge\tMarks\tbranch\n");
	printf("%s\t%d\t%d\t%s",p->name,p->age,p->marks,p->branch);
}
