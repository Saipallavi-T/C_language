#include<stdio.h>
main()
{
	char str[10];
	printf("Enter the string\n");
	gets(str);
	int i,n;
	printf("Enter number of string elements\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	printf("%3c",str[i]);
}
