#include<stdio.h>
main()
{
	char str[10];
	printf("Enter the string\n");
	gets(str);
	int i;
	for(i=0;i<10;i++)
	printf("%3c",str[i]);
}
