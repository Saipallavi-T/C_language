#include<stdio.h>
main()
{
	char str[10];
	printf("Enter the string\n");
	gets(str);
	puts(str);
}
