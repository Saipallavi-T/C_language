#include<stdio.h>
int strong(int);
main()
{
int n;
printf("Enter number\n");
scanf("%d",&n);
int temp=n;
if(temp==strong(n))
printf("STRONG");
else
printf("NOT STRONG");
}
int strong(int n)
{
	int i,fact,rem,sum=0;
	while(n>0)
{
	i=1,fact=1;
	rem=n%10;
	while(i<=rem)
	{
		fact=fact*i;
		i++;
	}
	sum=sum+fact;
	n=n/10;
}
return sum;
}

