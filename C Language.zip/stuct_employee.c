struct employee
{
	char name[10];
	int age;
	int salary;
}
main()
{
	struct employee *p,e;
	p=&e;
	printf("enter employee details\n");
	scanf("%s%d%d",p->name,&p->age,&p->salary);
	printf("Name\tAge\tSalary\n");
	printf("%s\t%d\t%d",p->name,p->age,p->salary);
}
