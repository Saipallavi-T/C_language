#include<stdio.h>
int i;
struct student
{
	char name[10];
	int age;
	float marks;
}e[10];
struct student read(int);
struct student del(int);
main()
{
	int n,ch;
	char c;
	do{
		printf("1.read\n 2.display\n 3.delete\n");
		printf("\n enter yor choice");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("enter size");
			       scanf("%d",&n);
			       printf("enter studen details");
			       for(i=0;i<n;i++)
			       e[i]=read(n);
			       break;
			       case 2:display(e,n);
			       break;
			       case 3:e[i]=del(n);
			       display(e,n-1);
			       break;
			       }
			       printf("press y to continue");
			       scanf(" %c",&c);
	}
	while(c=='y');
}
display(struct student e[],int(n))
{
	printf("-----------------------------Student Details-----------------------------\n");
	printf("Name\tAge\tmarks\n");
	for(i=0;i<n;i++)
	printf("%s\t%d\t%f\n",e[i].name,e[i].age,e[i].marks);
}
struct student read(int n)
{
	scanf("%s%d%f",e[i].name,&e[i].age,&e[i].marks);
	return e[i];
}
struct student del(int n)
{
	int pos;
	printf("Enter position");
	scanf("%d",&pos);
	for(i=pos-1;i<n;i++)
	e[i]=e[i+1];
}

