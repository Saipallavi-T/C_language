extern int a,b;
void sub1(int a,int b)
{
	printf("Result=%d",a-b);
}
