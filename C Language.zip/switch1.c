#include<stdio.h>
main()
{
	char t;
	char ch;
	do
	{
	printf("Enter a alphabet\n");
	scanf(" %c",&ch);
	switch(ch)
	{
		case 'a':
	    case 'e':
	    case 'i':
	    case 'o':
	    case 'u':printf("Vowel");
	    break;
	    default:printf("Consonent");
	    break;
	}   
	printf("\nPress y to continue");
    scanf(" %c",&t);
    }while(t=='y');	
}
