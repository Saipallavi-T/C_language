#include<stdio.h>
main()
{
	int ch;
	int a,b,c;
	float d;
	char t;
	do
	{
	printf("Press:1 for addition\n2 for subtraction\n3 for multiplication\n4 for division\n5 for modulus operator\n");
	printf("Enter the arithmatic operator\n");
	scanf("%d",&ch);
	printf("Enter two numbers\n");
	scanf("%d %d",&a,&b);
	switch(ch)
	{
		case 1:c=a+b;
		         printf("The result is %d",c);
		         break;
		case 2:c=a-b;
		         printf("The result is %d",c);
		         break;  
		case 3:c=a*b;
		         printf("The result is %d",c);
		         break;		
		case 4:d=(float)(a)/(float )(b);
		         printf("The result is %f",d);
		         break;
		case 5:printf("The result is %d",(a%b));
		         break;			         
	}
	printf("\nPress y to continue");
    scanf(" %c",&t);
    }while(t=='y');	
}
