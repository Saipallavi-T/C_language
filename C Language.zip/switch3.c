#include<stdio.h>
#include<math.h>
main()
{
	int ch;
	float a,b,c;
	char t;
	do{
	printf("Press:1 for addition\n2 for subtraction\n3 for multiplication\n4 for division\n5 for percentage\n6 for sruare root\n7 for power");
	printf("Enter the arithmatic operator\n");
	scanf("%d",&ch);
	printf("Enter two numbers\n");
	scanf("%f %f",&a,&b);
	switch(ch)
	{
		
		case 1:c=a+b;
		         printf("The result is %f",c);
		         break;
		case 2:c=a-b;
		         printf("The result is %f",c);
		         break;  
		case 3:c=a*b;
		         printf("The result is %f",c);
		         break;		
		case 4:c=a/b;
		         printf("The result is %f",c);
		         break;
		case 5:c=(a/100)*b;
		         printf("The result is %f",c);
		         break;
	    case 6:printf("The squareroot of a  is %f\n",sqrt(a));    
	           printf("The squareroot of b is %f",sqrt(b));  
			   break; 
	    case 7:printf("The result is %f",pow(a,b));
		       break;
	}
	printf("Press y to continue");
	scanf(" %c",&t);
}while(t=='y');
}
