#include<stdio.h>
main()
{
	char color,t;
	do
	{
	printf("Enter a vowel\n");
	scanf(" %c",&color);
	switch(color)
	{
		case 'a':printf("Apricot");
		break;
		case 'e':printf("Emerald Green");
		break;
		case 'i':printf("Indigo");
		break;
		case 'o':printf("Orange");
		break;
		case 'u':printf("Ultramarine");
		break;
		default:printf("Enter a vowl only!!");
	}
	printf("\nPress y to continue");
    scanf(" %c",&t);
    }while(t=='y');	
}
