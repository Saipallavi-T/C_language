#include<stdio.h>
main()
{
 int num;
 char t;
 do
 {
 printf("Enter a number between 0 and 9\n");
 scanf("%d",&num);
 switch(num)
 {
 case 0:printf("zero");
         break;	
 case 1:printf("one");
         break;	
 case 2:printf("Two");
         break;	
 case 3:printf("Three");
         break;	
case 4:printf("Four");
         break;
 case 5:printf("Five");
         break;	
case 6:printf("Six");
         break;	
case 7:printf("Seven");
         break;	
 case 8:printf("Eight");
         break;	
 case 9:printf("Nine");
         break;	
	}
	printf("\nPress y to continue");
    scanf(" %c",&t);
    }while(t=='y');	
}
