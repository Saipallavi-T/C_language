#include<stdio.h>
main()
{
  int tf,item,np,a;
  printf("1.tiffin\n2.snacks\n3.meals\n\n");
  printf("1.idly\n2.dosa\n3.wada\n\n");
  printf("1.pizza\n2.burger\n\n");
  printf("1.veg\n2.non veg\n\n");
  printf("type of item\nfood\nNo.of plates");
  scanf("%d %d %d",&tf,&item,&np);
  switch(tf)
  {  	case 1:switch(item)
	  {
  		case 1:a=np*10;
  		printf("the amount is %d",a);
		break;
	    case 2:a=np*5;
  		printf("the amount is %d",a);
  		break;
    	case 3:a=np*20;
  		printf("the amount is %d",a);
		break;
	  }
	  break;
	case 2:switch(item)
	  {
  		case 1:a=np*100;
  		printf("the amount is %d",a);
		break;
	    case 2:a=np*250;
  		printf("the amount is %d",a);
  		break;
    }
    break;
   case 3:switch(item)
   {
   	  case 1:a=np*50;
      printf("the amount is %d",a);
	  break;
	  case 2:a=np*100;
  	  printf("the amount is %d",a);
  	  break;
    }
    break;
}	
}
