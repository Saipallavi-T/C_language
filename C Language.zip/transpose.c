#include<stdio.h>
int i,j;
void display(int,int,int[][10]);
void display1(int,int,int[][10]);
main()
{
	int a[10][10],n,m;
	printf("enter row size\n");
	scanf("%d",&m);
	printf("enter coloum size\n");
	scanf("%d",&n);
	printf("Enter elements\n");
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		scanf("%d",&a[i][j]);
	}
	printf("Matrix\n");
	display(m,n,a);
	printf("Transpose Matrix\n");
	display1(m,n,a);
}
void display(int m,int n,int a[][10])
{
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	printf("%3d",a[i][j]);
	printf("\n");
    }
}
void display1(int m,int n,int a[][10])
{
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	printf("%3d",a[j][i]);
	printf("\n");
    }
}
