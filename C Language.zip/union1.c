union book
{
	char name[10];
	int pages;
	float price;
};
main()
{
	union book b;
	printf("Enter book name:");
	scanf("%s",b.name);
	printf("Name=%s\n",b.name);
	printf("Enter book Pages:");
	scanf("%d",&b.pages);
	printf("Pages=%d\n",b.pages);
	printf("Enter book price:");
	scanf("%f",&b.price);
	printf("Price=%f",b.price);	
}
