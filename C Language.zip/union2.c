union book
{
	char name[10];
	int age;
	float marks;
};
main()
{
	union book b;
	printf("Enter student name:");
	scanf("%s",b.name);
	printf("Name=%s\n",b.name);
	printf("Enter student age:");
	scanf("%d",&b.age);
	printf("age=%d\n",b.age);
	printf("Enter marks:");
	scanf("%f",&b.marks);
	printf("marks=%f",b.marks);	
}
