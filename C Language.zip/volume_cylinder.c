#include<stdio.h>
 main()
{
  float r,h;
  printf("enter height and radius\n");
  scanf("%f %f",&h,&r);
  float area=(3.14*r*r*h)*3/4;
  printf("volume is %f",area);
}
