#include<stdio.h>
main()
{
	int i=1;
	while(i<=10)
	{
		printf("welcome to sru\n");
		i++;
	}
}
